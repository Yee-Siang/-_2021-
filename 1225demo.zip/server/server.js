import WebSocket from 'ws';
import express from 'express';
import mongoose from 'mongoose';
import dotenv from "dotenv-defaults";
import http from 'http';
import cors from 'cors';
import bodyParser from 'body-parser';
import User from "../model/user.js"

///////////////////////////////////////////////////////////////////////////////

/* 連接資料庫 */
dotenv.config();
if (!process.env.MONGO_URL){
    console.error("Missing MONGO_URL!!");
    process.exit(1);
}
mongoose
    .connect(process.env.MONGO_URL,{
    useNewUrlParser:true,
    useUnifiedTopology:true,})
const db = mongoose.connection
db.on( "error" , ( e ) => {
    throw new Error( "DBConnectionError" + e )
})
const app =express();
const server = http.createServer( app );
const wss = new WebSocket.Server( { server } );
app.use( cors() );
app.use( bodyParser.json() );

/* 確定有連到資料庫 */
db.once( "open" , () => {
    console.log( "MongoDB connected!" )
    const PORT = process.env.port || 4000
    server.listen( PORT , () =>{
        console.log( `Listening on ${PORT}` )
    })
})

///////////////////////////////////////////////////////////////////////////////

/* 註冊新用戶(3/4) */
app.post( '/api/CreateNewUser' , async ( req , res ) => {
    let SignupUserID = req.body.SignupUserID;
    let SignupUserPassword = req.body.SignupUserPassword;
    let SignupNickname = req.body.SignupNickname;
    let SignupSchool = req.body.SignupSchool;
    let SignupBirthday = req.body.SignupBirthday;
    let SignupAboutMe = req.body.SignupAboutMe;
    
    console.log(SignupBirthday)
    const [response,SignupStatus] = await SaveNewUser( 
        SignupUserID , SignupUserPassword , SignupNickname , SignupSchool , SignupBirthday , SignupAboutMe );
    res.json( { Message: `${response}` , SignupSuccess:  `${SignupStatus}`} )
})

/* 註冊新用戶(4/4) */
const SaveNewUser = async ( UserID , Password , Nickname , School , Birthday , AboutMe) => {
    const existing = await User.findOne( { UserID : UserID } );
    if ( existing ) {try { return [`UserID ${UserID} has repeated !!` , false ] }
        catch( e ) { throw new Error( "User creation error" + e ) }}
    else {
        console.log( "BackendNowCreateNewUser" );
        try {
        const newUser = new User( { UserID , Password , Nickname , School , Birthday , AboutMe} );
        let nowreturn = newUser.save();
        console.log( "BackendFinishCreateNewUser" );
        return [`FrontendFinishCreateNewUser( ID: ${UserID} , PW: ${Password} , Nickname: ${Nickname} , School: ${School} )` ,
                true ];
        }
        catch( e ) { throw new Error( "User creation error" + e ) }}
}

///////////////////////////////////////////////////////////////////////////////

/* 舊用戶登入(3/4) */
app.post( '/api/UserLogin' , async ( req , res ) => {
    let InputUserID = req.body.LoginUserID;
    let InputUserPassword = req.body.LoginUserPassword;
    const [ response , LoginStatus , UserID , UserPassword , Nickname , School , Birthday , AboutMe] = 
        await UserLogin( InputUserID , InputUserPassword );
    res.json( { Message : `${response}` , LoginSuccess : `${LoginStatus}`,
                UserID : `${UserID}`,UserPassword : `${UserPassword}`, 
                Nickname : `${Nickname}`, School : `${School}` , Birthday : `${Birthday}` , AboutMe : `${AboutMe}`} 
            )}
        )

/* 舊用戶登入(4/4) */
const UserLogin = async ( UserID , Password ) => {
    const existing = await User.findOne( { UserID : UserID } );
    console.log( "BackendNowUserLogin" );
    if ( existing ) {try {
        if ( existing.Password === Password ){
            try{
                console.log( "BackendFinishUserLogin" );
                
                return [`FrontendFinishUserLogin( ID: ${UserID} , PW: ${Password})`, true ,existing.UserID , existing.Password , 
                        existing.Nickname , existing.School , existing.Birthday , existing.AboutMe]
            }
            catch( e ) { throw new Error( "User Login error" + e ) }
        }
        else {
            try{return [`Wrong Password!!` , false ,"","","","","","" ]}
            catch( e ) { throw new Error( "User Login error" + e ) }
        }
        }
        catch( e ) { throw new Error( "User Login error" + e ) }}
    else {
        try {
        return [`UserID is not existing !` , false ,"","","","","","" ];
        }
        catch( e ) { throw new Error( "User Login error" + e ) }}
}

///////////////////////////////////////////////////////////////////////////////

/*刪除所有使用者(3/4)*/
app.delete( '/api/DeleteAllUsers' , async ( req , res ) => {
    const response = await DeleteDB();
    res.json( { Message: `${response}` } )
    
});

/*刪除所有使用者(4/4)*/
const DeleteDB = async () => {
    try{
        console.log( "BackendNowDeleteAllUser" );
        await User.deleteMany( {} );
        console.log( "BackendFinishDeleteAllUser" );
        return `FrontendFinishDeleteAllUser` ;
    }
     catch( e ) { throw new Error( "database deletion failed" + e ) }
}

///////////////////////////////////////////////////////////////////////////////

/* 修改密碼(3/4) */
app.post( '/api/ChangePassword' , async ( req , res ) => {
    let InputUserID = req.body.NowUserID;
    let InputOldPassword = req.body.OldUserPassword;
    let InputNewPassword = req.body.NewUserPassword;
    const [ response , ChangePasswordStatus ] = await ChangePassword( InputUserID , InputOldPassword , InputNewPassword );
    res.json( { Message : `${response}` , ChangePasswordSuccess : `${ChangePasswordStatus}` } )
})

/* 修改密碼(4/4) */
const ChangePassword = async ( UserID , OldPassword , NewPassword ) => {
    const existing = await User.findOne( { UserID : UserID } );
    console.log( "BackendNowChangePassword" );
    try {
        if ( existing.Password === OldPassword ){
            try{
                User.updateOne(  { UserID : UserID } , { Password : NewPassword }, function (err, res) { })
                console.log( "BackendFinishChangePassword" );
                return [ `FrontendFinishChangePassword(ID: ${UserID},OldPW: ${OldPassword},NEWPW: ${NewPassword})` , true ]
            }
            catch( e ) { throw new Error( "Change Password error" + e ) }
        }
        else {
            try{ return [ `Wrong Password!!` , false ]}
            catch( e ) { throw new Error( "Change Password error" + e ) }
        }
    }
    catch( e ) { throw new Error( "Change Password error" + e ) }
    
}