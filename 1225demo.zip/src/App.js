import React, { useEffect , useState , useRef } from 'react'
import 'antd/dist/antd.css';
import { Button , Input , Tag  , Tooltip , Layout , Menu , Breadcrumb , Descriptions, Badge , DatePicker } from 'antd'
import { UserOutlined , SettingOutlined , SmileOutlined , DollarOutlined , 
         AuditOutlined , AlertOutlined  , PieChartOutlined , ScheduleOutlined ,
         FileOutlined , ReadOutlined , TeamOutlined , CarOutlined ,
         ToolOutlined } from '@ant-design/icons';
import axios from './api';

function App() {
///////////////////////////////////////////////////////////////////////////////

  /* PageState 為顯示的界面 */
  const [ PageState , setPageState ] = useState( "Welcome" )

  /* LoginUserID , LoginUserPassword 為登入 input 欄位中的帳密 */
  const [ LoginUserID , setLoginUserID ] = useState("")
  const [ LoginUserPassword , setLoginUserPassword ] = useState("")

  /* 註冊 input 欄位中的帳密及基本資料 */
  const [ SignupUserID , setSignupUserID ] = useState("")
  const [ SignupUserPassword , setSignupUserPassword ] = useState("")
  const [ SignupNickname , setSignupNickname ] = useState("")
  const [ SignupSchool , setSignupSchool ] = useState("")
  const [ SignupBirthday , setSignupBirthday ] = useState(["","",""])
  const [ SignupAboutMe , setSignupAboutMe ] = useState("")

  /* HasLogin 為目前已經登入 */
  const [ HasLogin , setHasLogin ] = useState(false)

  /* 目前已經登入的使用者的帳密及基本資料 */
  const [ NowUserID , setNowUserID ] = useState("")
  const [ NowUserPassword , setNowUserPassword ] = useState("")
  const [ NowNickname , setNowNickname ] = useState("")
  const [ NowSchool , setNowSchool ] = useState("")
  const [ NowBirthday , setNowBirthday ] = useState(["","",""])
  const [ NowAboutMe , setNowAboutMe ] = useState("")

  /* OldUserPassword , NewUserPassword 為使用者改密碼時的的舊/新密碼 */
  const [ OldUserPassword , setOldUserPassword ] = useState("")
  const [ NewUserPassword , setNewUserPassword ] = useState("")

  /* SystemMessage,SystemMessageColor 為顯示在底部 ( footer ) 的系統訊息和文字顏色 */
  const [ SystemMessage , setSystemMessage ] = useState("Welcome to エムエム")
  const [ SystemMessageColor , setSystemMessageColor ] = useState("#3E00FF") /*藍色*/

  /*側邊選單的Logo和收起/展開狀態，預設為展開*/
  const [ SiderLogo , setSiderLogo ] = useState("🥺😳😎🥺😳😎")
  const [ SiderOnCollapse , setSiderOnCollapse ] = useState(false)
  

  
///////////////////////////////////////////////////////////////////////////////

  /*刪除所有使用者(2/4)*/
  const handleDeleteAllUsers =  async() => {
    console.log( "FrontendNowDeleteAllUser" )
    const { data: { Message }} = await axios.delete( '/api/DeleteAllUsers' );
    console.log( Message )
    setSystemMessage( Message );
    setSystemMessageColor("#000000") /*黑色*/
  };

  /*註冊新用戶(2/4)*/
  const handleCreateNewUser =  async() => {
    console.log( "FrontendNowCreateNewUser" )
    const { data: { Message , SignupSuccess } } = await axios.post('/api/CreateNewUser', 
    { SignupUserID , SignupUserPassword , SignupNickname , SignupSchool , SignupBirthday , SignupAboutMe });
    console.log( Message )
    if ( SignupSuccess === "true" ){ 
      setSystemMessage( Message );
      setSystemMessageColor("#3E00FF") /*藍色*/
    }
    else {setSystemMessage( Message );setSystemMessageColor("#EC255A")} /*紅色*/ 
  };

  /*舊用戶登入(2/4)*/
  const handleUsersLogin =  async() => {
    console.log( "FrontendNowUserLogin" )
    const { data:  { Message , LoginSuccess , UserID , UserPassword , Nickname , School , Birthday , AboutMe }} = 
      await axios.post('/api/UserLogin', { LoginUserID , LoginUserPassword });
    console.log( Message )

    if ( LoginSuccess === "true" ){
      setHasLogin( true )
      setPageState( "Login" )
      setNowUserID( UserID )
      setNowUserPassword( UserPassword )
      setNowNickname( Nickname )
      setNowSchool( School )
      setNowBirthday( [Birthday.split(",")[0],Birthday.split(",")[1],Birthday.split(",")[2]] )
      setNowAboutMe( AboutMe )
      setSystemMessage( Message )
      setSystemMessageColor("#3E00FF") /*藍色*/ 
    }
    else {setSystemMessage( Message );setSystemMessageColor("#EC255A")} /*紅色*/ 
  };

  /*修改密碼(2/4)*/
  const handleChangePassword =  async() => {
    console.log( "FrontendNowChangePassword" )
    const { data:  {Message,ChangePasswordSuccess}} = await axios.post('/api/ChangePassword', 
    { NowUserID , OldUserPassword , NewUserPassword });
    console.log( Message )
    if (  ChangePasswordSuccess === "true" ){
      setNowUserPassword( NewUserPassword )
      setSystemMessage( Message )
      setSystemMessageColor("#3E00FF") /*藍色*/ 
    }
    else {setSystemMessage( Message );setSystemMessageColor("#EC255A")} /*紅色*/ 
  };

///////////////////////////////////////////////////////////////////////////////

//登入前歡迎頁面
  const WelcomePage=
    <Layout.Content>
      <div /* 輸入使用者帳號 */> 
      <p>To Login , Please Enter Your ID</p>
      <Input onChange = { ( e ) => { setLoginUserID( e.target.value ) }}
            placeholder = "Enter your UserID"
            prefix = { <UserOutlined /> }
      />
      </div>
      <div /* 輸入使用者密碼 */>
      <p>Please Enter Your Password</p>
      <Input onChange = { ( e ) => { setLoginUserPassword( e.target.value ) }}
            placeholder = "Enter your Password"
            prefix = { <UserOutlined /> }
      />
      </div>
      <div /* 舊用戶登入(1/4) */>
      <Button onClick = { handleUsersLogin }
              disabled = { !LoginUserID || !LoginUserPassword }
              type = "primary"
      >Login</Button>
      </div>
      <div /* 註冊按鈕 */>
      <p>First Time To エムエム ? Please Signup First</p>
      <Button onClick = { ()=> { setPageState( "Signup" );
                                 setSignupUserID("");
                                 setSignupUserPassword(""); 
                                 setSignupNickname("");
                                 setSignupSchool(""); 
                                 setSignupBirthday(["","",""])
                                 setSignupAboutMe("");  
                                 setSystemMessage( "Welcome to エムエム" )
                                 setSystemMessageColor("#3E00FF") /*藍色*/            
      }}
              type = "primary"
      >Signup</Button>
      </div>
      <div /* 刪除所有使用者(1/4) */>
      <Button onClick = { handleDeleteAllUsers }
              type = "danger"
            
      >Delete All Users</Button>
      </div>
    </Layout.Content>
    
//已登入的主頁面
  const LoginPage=
    <Layout.Content>
      <p>Welcome back 🥺🥺 { NowUserID } 🥺🥺 Please choose the servive </p>
    </Layout.Content>
        
//註冊頁面
  const SignupPage=
    <Layout.Content>
      <p>🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺</p> 
      <p>🥺 This is WelcomeエムエムPage🥺</p> 
      <p>🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺🥺</p> 
      <p>This is Signup Page</p>
      <div /* 註冊輸入帳號 */>
        <p>Please Enter Your ID *</p>
        <Input onChange = { ( e ) => { setSignupUserID( e.target.value ) }}
               placeholder = "Enter your UserId"
               prefix = { <UserOutlined /> }
        />
      </div>
      <div /* 註冊輸入密碼 */>
        <p>Please Enter Your Password *</p>
        <Input onChange = { ( e ) => { setSignupUserPassword( e.target.value ) }}
               placeholder = "Enter your UserPassword"
               prefix = { <UserOutlined /> }
        />
      </div>
      <div /* 註冊輸入暱稱 */>
        <p>Please Enter Your Nickname *</p>
        <Input onChange = { ( e ) => { setSignupNickname( e.target.value ) }}
               placeholder = "Enter your Nickname"
               prefix = { <UserOutlined /> }
        />
      </div>
      <div /* 註冊輸入學校 */>
        <p>Please Enter Your School</p>
        <Input onChange = { ( e ) => { setSignupSchool( e.target.value ) }}
               placeholder = "Enter your School (optional)"
               prefix = { <UserOutlined /> }
        />
      </div>
      <div /* 註冊輸入生日 */>
        <p>Please Enter Your Birthday</p>
        <DatePicker onChange = { ( e ) => { !e ? setSignupBirthday( ["","",""] ) :
          setSignupBirthday( [ String( e ).split(" ")[3] , String( e ).split(" ")[1] , String( e ).split(" ")[2] ] )}}
                    placeholder = "Enter your Birthday (optional)"
                    style = { { width : "300px" } }
                    
        />
      </div>


      <div /* 註冊輸入個人簡介 */>
        <p>We want to know you more,please enter something</p>
        <Input.TextArea onChange = { ( e ) => { setSignupAboutMe( e.target.value ) }}
                        placeholder = "About me ... (optional)"
                        rows = { 3 }
        />
  
      </div>

      <div /* 註冊新用戶(1/4) */>
        <Button type = "primary"
                onClick = { handleCreateNewUser }
                disabled = { !SignupUserID || !SignupUserPassword || !SignupNickname }
        >Submit</Button>
      </div>
      <div /* 放棄註冊 */>
        <Button type = "danger"
                onClick = { () => { setPageState("Welcome")
                                    setLoginUserID("");
                                    setLoginUserPassword("");
                                    setSystemMessage( "Welcome to エムエム" )
                                    setSystemMessageColor("#3E00FF") /*藍色*/
        }}>Go back</Button>
      </div>
    </Layout.Content>

//處理月份英文名稱到數字的轉換
  const MonthToNumber = ( Month ) => {
    if ( Month === "Jan" ) { return ( "01" ) }
    if ( Month === "Feb" ) { return ( "02" ) }
    if ( Month === "Mar" ) { return ( "03" ) }
    if ( Month === "Apr" ) { return ( "04" ) }
    if ( Month === "May" ) { return ( "05" ) }
    if ( Month === "Jun" ) { return ( "06" ) }
    if ( Month === "Jul" ) { return ( "07" ) }
    if ( Month === "Aug" ) { return ( "08" ) }
    if ( Month === "Sep" ) { return ( "09" ) }
    if ( Month === "Oct" ) { return ( "10" ) }
    if ( Month === "Nov" ) { return ( "11" ) }
    if ( Month === "Dec" ) { return ( "12" ) }
    return ""
  }

//個人資訊頁面
  const PersonalInfoPage =
    <Layout.Content>
      <p>This is Personal Info Page</p>
      <Descriptions  bordered column = { 1 } >
        <Descriptions.Item  label = "UserId" >{ NowUserID }</Descriptions.Item>
        <Descriptions.Item  label = "Password">{ NowUserPassword }</Descriptions.Item>
        <Descriptions.Item  label = "Nickname">{ NowNickname }</Descriptions.Item>
        <Descriptions.Item  label = "School">{ NowSchool === "" ? "Not Set" : NowSchool }</Descriptions.Item>
        <Descriptions.Item  label = "Birthday">{ NowBirthday[0] === "" ? "Not Set" : 
        `${ NowBirthday[0] }-${ MonthToNumber( NowBirthday[1] ) }-${ NowBirthday[2] }` }</Descriptions.Item>
        <Descriptions.Item  label = "About me">{ NowAboutMe === "" ? "Not Set" : NowAboutMe }</Descriptions.Item>
      </Descriptions>
    </Layout.Content>

//備忘錄頁面
const MemoPage =
    <Layout.Content>
      <p>This is Memo Page</p>
      
    </Layout.Content>

//記帳本頁面
const SpendingPage =
    <Layout.Content>
      <p>This is Spending Page</p>
    </Layout.Content>

//聊天室頁面
  const ChatroomPage =
    <Layout.Content>
      <p>This is Chatroom Page</p>
      
    </Layout.Content>

//學習功能頁面
  const LearningPage =
    <Layout.Content>
      <p>This is Learning Page</p>
      
    </Layout.Content>

//一般設定頁面
  const NormalSettingPage =
    <Layout.Content>
      <p>This is Normal Setting Page</p>
     
    </Layout.Content> 
    
//帳號設定頁面
  const AccountSettingPage =
    <Layout.Content>
      <p>This is Account Setting Page</p>
      <div /* 修改密碼(1/4) */>
        <p>Change your password here</p>
        <p>Please your Old password </p>
        <Input onChange = { ( e ) => { setOldUserPassword( e.target.value )}}
               placeholder = "Enter your OldPassword"
               prefix = { <UserOutlined /> }
        />
        <p>Please your New password </p>
        <Input onChange = { ( e ) => { setNewUserPassword( e.target.value )}}
               placeholder = "Enter your NewPassword"
               prefix = { <UserOutlined /> }
        />
        <Button onClick = { handleChangePassword }
                disabled = { !OldUserPassword || !NewUserPassword }
                type = "primary"
        >Submit</Button>
      </div>
     
    </Layout.Content> 

///////////////////////////////////////////////////////////////////////////////

//處理側邊選單收起/展開時Logo的改變
const handleSiderCollapse = () => {
  if (!SiderOnCollapse){
    setSiderOnCollapse(true) ;setSiderLogo("🥺")}
  else {
    setSiderOnCollapse(false) ;setSiderLogo("🥺😳😎🥺😳😎")}
}


//側邊的選單，登入前只有welcome，登入後可選功能
const PageSider = () => {
  if ( HasLogin === false ){
    return (
      <Layout.Sider style={ { background : "#98BAE7" , height : "auto" } } >🥺😳😎 エムエム_2021α</Layout.Sider>)
  }
  else{
    return(
      <Layout.Sider collapsible
        onCollapse={handleSiderCollapse}
        style = { { background : "#98BAE7" , height : "auto" } } >
        <p>This is Login Sider!</p>
        <p style = { SiderOnCollapse ? {fontSize : "50px" , lineHeight : "10px"} : {fontSize : "30px" , lineHeight :"0px"} }
        >{ SiderLogo }</p>
        <Menu theme = "dark"   /* 各種功能和登出按鈕 */
              defaultSelectedKeys = { [ "Login" ] }
              mode = "inline" >
          <Menu.Item onClick = { () => { setPageState( "Login" )
                                         setSystemMessage(`Welcome back , ${NowUserID}`)
                                         setSystemMessageColor("#3E00FF") /*藍色*/
        
        }} 
                     key = "Login" 
                     icon = { <SmileOutlined /> }>Welcome</Menu.Item>
          <Menu.Item onClick = { () => { setPageState( "PersonalInfo" )}} 
                     key = "PersonalInfo" 
                     icon = { <UserOutlined /> }>Personal Info</Menu.Item>





          <Menu.SubMenu   /* 提醒事項的子選單，分為備忘錄（memo）跟記帳區（spending）*/
                     title = "Reminder"
                     key = "Reminder" 
                     icon = { <AlertOutlined /> }>
            <Menu.Item onClick = { () => { setPageState( "Memo" )}} 
                       key = "Memo" 
                       icon = { <AuditOutlined /> }>Memo</Menu.Item>
            <Menu.Item onClick = { () => { setPageState( "Spending" ) }} 
                       key = "Spending" 
                       icon = { <DollarOutlined /> }>Spending</Menu.Item>

          </Menu.SubMenu>


          <Menu.Item onClick = { () => { setPageState( "Chatroom" )}} 
                     key = "Chatroom" 
                     icon = { <TeamOutlined /> }>Chatroom</Menu.Item>
          <Menu.Item onClick = { () => { setPageState( "Learning" )}} 
                     key = "Learning" 
                     icon = { <ReadOutlined /> }>Learning</Menu.Item>
          
          <Menu.SubMenu   /* 設定的子選單，分為一般設定（改界面和使用者基本資料）跟帳號設定（改密碼）*/
                     title = "Setting"
                     key = "Setting" 
                     icon = { <SettingOutlined /> }>
            <Menu.Item onClick = { () => { setPageState( "NormalSetting" )}} 
                       key = "NormalSetting" 
                       icon = { <PieChartOutlined /> }>NormalSetting</Menu.Item>
            <Menu.Item onClick = { () => { setPageState( "AccountSetting" )
                                           setOldUserPassword("")
                                           setNewUserPassword("")
                                         }} 
                       key = "AccountSetting" 
                       icon = { <ToolOutlined /> }>AccountSetting</Menu.Item>

          </Menu.SubMenu>
          
          <Menu.Item onClick = { () => {setPageState("Welcome");
                                        setLoginUserID("");
                                        setLoginUserPassword("");
                                        setHasLogin(false)
                                        setNowUserID("")
                                        setNowUserPassword("")
                                        setNowNickname("")
                                        setNowSchool("")
                                        setNowBirthday(["","",""])
                                        setNowAboutMe("")
                                        setSystemMessage( "Welcome to エムエム" )
                                        setSystemMessageColor("#3E00FF") /*藍色*/
                                      }}
                     key = "7 "
                     icon = { <CarOutlined /> } >Signout</Menu.Item>
        </Menu>
      </Layout.Sider>
    )
  }
}

//目前頁面內容
  const NowPageContent=()=>{
    if ( PageState === "Welcome" )
    {return ( WelcomePage )}
    else if ( PageState === "Login" )
    {return ( LoginPage )}
    else if ( PageState === "Signup" )
    {return ( SignupPage )}
    else if ( PageState === "PersonalInfo" )
    {return ( PersonalInfoPage )}
    else if ( PageState === "Memo" )
    {return ( MemoPage )}
    else if ( PageState === "Spending" )
    {return ( SpendingPage )}
    else if ( PageState === "Chatroom" )
    {return ( ChatroomPage )}
    else if ( PageState === "Learning" )
    {return ( LearningPage )}
    else if ( PageState === "NormalSetting" )
    {return ( NormalSettingPage )}
    else if ( PageState === "AccountSetting" )
    {return ( AccountSettingPage )}
  }

//底部訊息，包含系統發送給前端的任何訊息
  const PageFooter = () => {
    return (
      <Layout.Content style = { { background : "#B8E4F0" } } >
        <p style = { { color : SystemMessageColor } } > { SystemMessage } </p>
        <p>2021🥺wp1101🥺final🥺🥺🥺🥺🥺 🥺 🥺 🥺 🥺 🥺 🥺 🥺 🥺 🥺🥺  </p>
        
      </Layout.Content>
    )
  }

//回傳側邊選單+頁面內容+底部訊息
  return(
    <Layout>
      { PageSider() }
      <Layout>
        { NowPageContent() }
        { PageFooter() }
      </Layout>
    </Layout>
  )

}

export default App;
